# Electricity_Tariff_Year1_Term2 [โปรแกรมคำนวณอัตราค่าไฟฟ้า]
